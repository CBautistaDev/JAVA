public class Room

{
	// Instance variables
	String name;
	String description;
	String[] exits;
	Artifact artifact;
	SpecialArtifact SpecialArtifact;;
	String reallyCoolDescription;
	String otherdescription;

	Room() {
	}

	Room(String name, String description, String exits[])

	{
		this.name = name;
		this.description = description;
		this.exits = exits;

	}

	boolean isValidExit(String requestedExit) {
		boolean result = false;
		int index = 0;
		while (result == false && index < exits.length) {
			if (exits[index].equals(requestedExit))
				result = true;
			index++;
		}

		return result;
	}

	String look() {
		if (artifact != null)
			return this.artifact.name;
		else
			return " an empty room";
	}

	String examine() {
		if (artifact != null)
			return this.artifact.description;
		else
			return " an empty room";
	}

	String touch() {
		if (SpecialArtifact != null)
			return this.SpecialArtifact.reallyCoolDescription;
		else
			return " this doesn't seem to do anything";
	}

}
