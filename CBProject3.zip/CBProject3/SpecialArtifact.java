public class SpecialArtifact extends Artifact {

	boolean powerState, didtouch, didexamine;
	String reallyCoolDescription;
	SpecialArtifact SpecialArtifact;
	String onDescription;
	String offDescription;
	String touchonDescription;
	String touchoffDescription;

	SpecialArtifact(String name) {
		super(name);
	}

	SpecialArtifact(String name, String description, boolean state, String reallyCoolDescription) {
		super(name, description);
		powerState = state;

		this.reallyCoolDescription = reallyCoolDescription;
	}

	// User examines special artifacts that allow special description to be
	// viewed
	String examine() {
		didexamine = true;
		if (powerState == false) {
			return this.description;
		}

		return this.reallyCoolDescription;
	}

	// User touches special arti fact, display appropriate messages
	String touch() {
		if (!powerState && didexamine) {
			didtouch = true;
			this.powerState = true;
			return this.reallyCoolDescription;
		}

		this.powerState = false;
		return this.description;
	}

}
