
public class Map {
	// Instance variables
	Room[][] rooms = new Room[4][4];

	Map() {
		// Local Variables
		// Create rooms
		Room library = new Room("Library", "Thousands of books to choose from \n exit East and South",
				new String[] { "e", "s" });

		Room building = new Room("Business Building", "Many trees and buildings to study under \n Exit South and West ",
				new String[] { "s", "w" });

		Room classroom = new Room("Class Room", "Professor lecturing a classroom. \n exit South and North and East ",
				new String[] { "e", "n", "s" });

		Room garden = new Room("Rose Garden", "Beautiful flowers all around  \n exit West and East and North",
				new String[] { "w", "e", "n" });

		Room food = new Room("Einsten Bagels", "The smell of bagels is delicious \n exit West and South",
				new String[] { "w", "s" });

		Room mansion = new Room("Kellong Mansion", "A beautiful house that has so much history. \n exit North and East",
				new String[] { "n", "e" });

		Room olivos = new Room("Los Olivos",
				"So many foods to choose from and drinks to quench the hungry \n exit West and East",
				new String[] { "w", "e" });

		Room rock = new Room("Voorhis Park",
				"Surrounded by tree and benches to sit on. Very calm \n Exit East and West and North",
				new String[] { "n", "w", "e" });

		Room express = new Room("Panda Express",
				"The orange chicken and rice make an excellent combination \n exit South and West",
				new String[] { "s", "w" });

		Room canyon = new Room("Box Canyon",
				"You have entered a Box Canyon \n Established in the 1970’s you can imagine it is old.\n Their is an exit North and East and NorthEast",
				new String[] { "ne", "n", "e" });

		Room dorms = new Room("Dorms", "A place where student come to unwind after a long day \n exit West and East  ",
				new String[] { "w", "e" });

		Room coffehouse = new Room("Starbucks",
				"The smell of coffee is amazing and many students lined up to get some \n exit East and West ",
				new String[] { "e", "w" });

		Room store = new Room("Book Store", "A place filled with books to buy and CPP wear.  \n exit North and west ",
				new String[] { "n", "w" });

		// Place rooms on Map
		rooms[0][0] = library;
		rooms[0][1] = building;
		rooms[1][0] = classroom;
		rooms[1][1] = garden;
		rooms[1][2] = food;
		rooms[2][0] = mansion;
		rooms[2][1] = olivos;
		rooms[2][2] = rock;
		rooms[2][3] = express;
		rooms[3][0] = canyon;
		rooms[3][1] = dorms;
		rooms[3][2] = coffehouse;
		rooms[3][3] = store;

		// Create artifacts
		Artifact book = new Artifact("a book", "A dusty leather-bound book."); // new
		Artifact table = new Artifact("a table", "A big table to study");
		Artifact PC = new Artifact("a PC", " A Windows powered computer");
		SpecialArtifact lamp = new SpecialArtifact("a lamp", "A brass lamp of great antiquity.", true, "Lamp glows"); // new
		SpecialArtifact phone = new SpecialArtifact("an Iphone", "A IOS device made by apple", true, "Phone turns on ");
		SpecialArtifact exam = new SpecialArtifact("an exam", " A midterm that someone failed", true,
				"Writing appears");

		// Place artifacts in rooms
		library.artifact = book;
		classroom.artifact = table;
		building.artifact = PC;
		coffehouse.artifact = lamp;
		store.artifact = phone;
		dorms.artifact = exam;

	}

}
