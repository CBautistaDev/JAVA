
public interface AccountConstants {

    public static final double CHECKING_BALANCE_THRESHOLD = 1000;
    public static final double TRANFER_FEE = 2.0;

}
