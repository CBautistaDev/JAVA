public class SpecialArtifact extends Artifact {

	boolean powerState;
	String reallyCoolDescription;
	SpecialArtifact SpecialArtifact;
	String onDescription;
	String offDescription;
	String touchonDescription;
	String touchoffDescription;

	SpecialArtifact(String name) {
		super(name);
	}

	SpecialArtifact(String name, String description, boolean state, String reallyCoolDescription) {
		super(name, description);
		powerState = state;

		this.reallyCoolDescription = reallyCoolDescription;
	}

	String touch() {
		if (powerState == true)
			return reallyCoolDescription;
		else
			return description;
	}

}
