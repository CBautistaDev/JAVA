import java.util.Scanner;

public class GCPUAPP {

	public static void main(String[] args) {
		// Staring location
		int row = 3;
		int col = 0;
		// Create and instance of the map
		Map mapGCPU = new Map();
		// Create a scanner for user dialog
		Scanner scan = new Scanner(System.in);
		// Begin user dialog
		System.out.println("Welcome to the Great Cal Poly Underground");

		String input = "";
		while (!input.equalsIgnoreCase("quit")) {
			System.out.println(mapGCPU.rooms[row][col].name);
			System.out.println(mapGCPU.rooms[row][col].description);
			System.out.print(">");
			input = scan.nextLine().toLowerCase();
			if (input.equals("e")) // move east
				if (mapGCPU.rooms[row][col].isValidExit("e"))
					col++;
				else
					System.out.println("You can't go that way .");
			else if (input.equals("w"))// move west
				if (mapGCPU.rooms[row][col].isValidExit("w"))
					col--;
				else
					System.out.println("You can't go that way .");
			else if (input.equals("n"))// move north
				if (mapGCPU.rooms[row][col].isValidExit("n"))
					row--;
				else
					System.out.println("You can't go that way.");
			else if (input.equals("s"))// move south
				if (mapGCPU.rooms[row][col].isValidExit("s"))
					row++;
				else
					System.out.println("You can't go that way.");
			else if (input.equals("ne"))// move northwest
				if (mapGCPU.rooms[row][col].isValidExit("ne")) {
					col++;
					row--;
				} else
					System.out.println("You can't go that way.");

			else if (input.equals("look"))
				System.out.println("You see " + mapGCPU.rooms[row][col].look()); // new
			else if (input.equals("examine"))
				System.out.println(mapGCPU.rooms[row][col].examine());
			else if (input.equals("touch"))
				System.out.println(mapGCPU.rooms[row][col].touch());

			else if (input.equalsIgnoreCase("quit")) {

				// See if user wants to continue
				System.out.println("Do you wish to leave the Underground (Y/N)? >");
				if (scan.nextLine().equals("y")) {
					break;
				}
				// If the input wasn't Y or YES, assume NO
				if (!input.equalsIgnoreCase("y")) {
					// reset input to prevent app from quitting
					input = "";
				}
			}
			// if user enters other words than quit
			else {
				System.out.println("I don't recognize the word '" + input + "'");
			}
		} // while
		System.out.println("Thank you for visiting the Underground.");
	} // main
} //