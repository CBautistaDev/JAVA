public class Artifact {
	String name, description;

	Artifact(String name) {
		this.name = name;
	}

	Artifact(String name, String description) {
		this(name);
		this.description = description;

	}

	String examine()

	{
		return description;

	}

	String touch() {
		return description;
	}

}
