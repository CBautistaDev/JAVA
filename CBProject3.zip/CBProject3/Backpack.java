import java.io.PrintWriter;
import java.util.ArrayList;

// Example of possible methods for the Backpack class.
// Be sure to read the assignment and implement the variables, constants, and
// methods as required.
public class Backpack {
	// Instance variables
	public ArrayList<Artifact> contents = new ArrayList<Artifact>();

	// Instance methods
	public void add(Artifact anyArtifact) {
		contents.add(anyArtifact);
	}

	public String getArtifact(int index) {
		return contents.get(index).name;
	}

	public String removeArtifact() {
		String message = "";
		for (int index = 0; index < contents.size(); index++)
			message += contents.get(index).name + "\n";

		return message;
	}

	public int count()// returns how many items are in the inventory.
	{
		return contents.size();
	}

	public String list() {
		if (contents.size() == 1)
			return "You are carrying " + this.contents.get(0).name + ".";
		else if (contents.size() == 2)
			return "You are carrying " + this.contents.get(0).name + " and " + this.contents.get(1).name + ".";
		else if (contents.size() == 3)
			return "You are carrying " + this.contents.get(0).name + ", " + this.contents.get(1).name + " and "
					+ this.contents.get(2).name + ".";
		else
			return "Your pack is empty";
	}

	void save(PrintWriter pw) {
		for (int index = 0; index < contents.size(); index++) {
			pw.println("Inventory" + "," + this.contents.get(index).name);
		}
	}

}
