import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class GCPUApp {

	public static void main(String[] args) {
		new GCPUApp();
	}

	// Starting location
	int row = 3;
	int col = 0;
	int aRow;

	GCPUApp() {
		// Create an instance of the map
		Map map = new Map(null);
		Backpack pack = new Backpack();
		Room room = null;
		// Create a scanner for user dialog
		Scanner scan = new Scanner(System.in);
		// Begin user dialog
		System.out.println("Welcome to the Great Cal Poly Underground");

		String input = "";
		while (!input.equalsIgnoreCase("quit")) {
			System.out.println(map.rooms[row][col].name);
			System.out.println(map.rooms[row][col].description);
			System.out.print(">");
			input = scan.nextLine().toLowerCase();
			if (input.equals("e")) // move east
				if (map.rooms[row][col].isValidExit("e"))
					col++;
				else
					System.out.println("You can't go that way .");
			else if (input.equals("w"))// move west
				if (map.rooms[row][col].isValidExit("w"))
					col--;
				else
					System.out.println("You can't go that way .");
			else if (input.equals("n"))// move north
				if (map.rooms[row][col].isValidExit("n"))
					row--;
				else
					System.out.println("You can't go that way.");
			else if (input.equals("s"))// move south
				if (map.rooms[row][col].isValidExit("s"))
					row++;
				else
					System.out.println("You can't go that way.");
			else if (input.equals("ne"))// move northwest
				if (map.rooms[row][col].isValidExit("ne")) {
					col++;
					row--;
				} else
					System.out.println("You can't go that way.");

			else if (input.equals("look"))
				System.out.println("You see " + Map.rooms[row][col].look()); // new
			else if (input.equals("examine"))
				System.out.println(map.rooms[row][col].examine());
			else if (input.equals("touch"))
				System.out.println(map.rooms[row][col].touch());
			else if (input.equals("restore"))
				restore();
			else if (input.equals("save"))
				save();
			else if (input.equals("take")) {
				pack.add(Room.artifact);
				Room.artifact = null;
				System.out.println("You are carrying: \n" + pack.removeArtifact());
			} else if (input.equals("drop")) {
				drop();
			}

			else if (input.equals("inventory")) // displays the list of items in
												// the pack.
			{
				System.out.println(pack.list());

			} else if (input.equals("help")) {

				System.out.println("Instructions: Move around in this map of Cal Poly Pomona.");
				System.out.println("to move use the keyboard to type the letter of direction you wish to move");
				System.out.println("n = north, south = south, NorthEast = ne, e = East, w = west");
				System.out.println("You can also type Look, Examine, Touch, Take, and Drop");
				System.out.println("If you want to quit the game type= quit");

			}

			else if (input.equalsIgnoreCase("quit")) {

				// See if user wants to continue
				System.out.println("Do you wish to leave the Underground (Y/N)? >");
				if (scan.nextLine().equals("y")) {
					break;
				}

				if (!input.equalsIgnoreCase("y")) {

					input = "";
				}
			}
			// if user enters other words than quit
			else {
				System.out.println("I don't recognize the word '" + input + "'");
			}
		} // while
		System.out.println("Thank you for visiting the Underground.");
	} // main

	void restore() {
		// Declare variables
		String fileName;

		// File path formats for Windows and Mac are shown below
		// Choose one of them and adjust for your computer's file structure
		// Windows:
		// fileName = "c:/java/GCPU1.txt";
		// Mac:
		fileName = "/volumes/MacIntosh HD//Users/charliebatista/Desktop/Java/GCPU1.txt";

		try {
			// Open requested file
			File file = new File(fileName);
			FileReader reader = new FileReader(file);
			BufferedReader buffer = new BufferedReader(reader);

			// Erase old artifacts from the map
			Map.rooms[0][0].artifact = null;
			Room.artifact = null;
			Map.rooms[1][0].artifact = null;
			Map.rooms[3][1].artifact = null;
			Map.rooms[3][2].artifact = null;
			Map.rooms[3][3].artifact = null;
			// Begin file processing
			String line = buffer.readLine();
			while (line != null) {
				String[] data = line.split("=|,");
				String key = data[0];
				if (key.equals("StartLocation")) {
					row = Integer.parseInt(data[1]);
					col = Integer.parseInt(data[2]);
				} else if (key.equals("Artifact")) {
					String name = data[1];
					int aRow = Integer.parseInt(data[2]);
					int aCol = Integer.parseInt(data[3]);
					if (name.equals("lamp"))
						Map.rooms[aRow][aCol].artifact = Map.lamp;
					else if (name.equals("book"))
						Map.rooms[aRow][aCol].artifact = Map.book;
					else if (name.equals("table"))
						Map.rooms[aRow][aCol].artifact = Map.table;
					else if (name.equals("PC"))
						Map.rooms[aRow][aCol].artifact = Map.PC;
					else if (name.equals("phone"))
						Room.artifact = Map.phone;
					else if (name.equals("exam"))
						Room.artifact = Map.exam;
					// continue adding code to process remaining artifacts
				}

				line = buffer.readLine();
			} // while

			buffer.close();
			reader.close();
			System.out.println(Map.rooms[row][col].name);
		} catch (IOException error) {
			System.out.println(error.getLocalizedMessage());
		}
	} // restore

	void drop() {

	}

	void save() {
		// Declare variables
		String fileName;
		String answer;
		Scanner scan = new Scanner(System.in);

		// File path formats for Windows and Mac are shown below
		// Mac:
		fileName = "/volumes/MacIntosh HD/Users/charliebatista/Desktop/Java/GCPU1.txt";

		try

		{
			System.out.println("\nThis save file already exists. Do you want to overwrite it or cancel? (yes/cancel)");
			System.out.print("> ");
			answer = scan.nextLine();

			if (answer.equalsIgnoreCase("yes")) {

				File file = new File(fileName);
				FileWriter writer = new FileWriter(file);
				BufferedWriter buffer = new BufferedWriter(writer);
				PrintWriter pw = new PrintWriter(buffer);

				pw.println("StartLocation" + "," + row + "," + col);

				for (int in = 0; in < Map.rooms[0][0].contentList.size(); in++)

				{

					pw.println("Artifact" + "," + (Map.rooms[0][0].contentList).get(in).name + "0,0");

				}
				for (int in = 0; in < Map.rooms[0][1].contentList.size(); in++)

				{

					pw.println("Artifact" + "," + (Map.rooms[0][1].contentList).get(in).name + "0,1");

				}

				buffer.close();
				pw.close();

				System.out.println("Save complete.");
			} else if (answer.equalsIgnoreCase("cancel")) {
				System.out.println("You have canceled.");
				answer = "yes";
			} else
				System.out.println("Please input yes or cancel.");
			while (!answer.equalsIgnoreCase("yes"))
				;
		} catch (

		IOException e) {
			System.out.println(e.getMessage());
		}
	} // save
} // class
	//