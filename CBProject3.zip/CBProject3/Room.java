import java.util.ArrayList;

public class Room

{
	// Instance variables
	String name;
	String description;
	String[] exits;
	static Artifact artifact;
	Backpack pack;

	SpecialArtifact SpecialArtifact;;
	String reallyCoolDescription;
	String otherdescription;
	public ArrayList<Artifact> contentList = new ArrayList<>();

	Room() {
	}

	Room(String name, String description, String exits[])

	{
		this.name = name;
		this.description = description;
		this.exits = exits;

	}

	boolean isValidExit(String requestedExit) {
		boolean result = false;
		int index = 0;
		while (result == false && index < exits.length) {
			if (exits[index].equals(requestedExit))
				result = true;
			index++;
		}

		return result;
	}

	String look() {
		if (artifact != null)
			return Room.artifact.name;
		else
			return " an empty room";
	}

	String examine() {
		if (artifact != null)
			return Room.artifact.description;
		else
			return " an empty room";
	}

	String touch() {
		if (artifact != null) {
			return artifact.touch();
		}
		return "There is nothing to touch.";
	}

}
